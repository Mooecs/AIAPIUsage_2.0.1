/**
 * AI API Toolkit — Utility Functions
 * Pure helpers with no dependencies on state or DOM.
 * Constants are in constants.js (loaded first).
 */

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

const fmtNum = (n) => Number(n || 0).toLocaleString();
const toUSD = (n) => '$' + (Number(n) / QUOTA_PER_USD).toFixed(2);
const toUSDDirect = (n) => '$' + Number(n).toFixed(2);
const API_KEY_PATTERN = /\bsk-[a-zA-Z0-9_\-]{12,}\b/g;
const API_URL_PATTERN = /https?:\/\/[a-zA-Z0-9][-a-zA-Z0-9._]*[a-zA-Z0-9](?::\d+)?(?:\/[^\s'",<>(){}[\]]*)*/g;

function extractApiKeysFromText(text) {
  const input = String(text || '').trim();
  if (!input) return [];

  const keys = [];
  const seen = new Set();
  for (const match of input.matchAll(API_KEY_PATTERN)) {
    const key = match[0];
    if (!seen.has(key)) {
      seen.add(key);
      keys.push(key);
    }
  }
  return keys;
}

function extractApiUrlsFromText(text) {
  const input = String(text || '').trim();
  if (!input) return [];

  const urls = [];
  const seen = new Set();
  for (const match of input.matchAll(API_URL_PATTERN)) {
    const url = normalizeBaseUrl(match[0].replace(/[.,;:!?)]+$/, '').replace(/\/v1$/i, ''));
    if (!url || seen.has(url)) continue;
    seen.add(url);
    urls.push(url);
  }
  return urls;
}

function parseApiKeyUrlPair(text) {
  const trimmed = String(text || '').trim();
  if (!trimmed) return null;

  const lines = trimmed.split(/\n/).map((line) => line.trim()).filter(Boolean);
  const keys = extractApiKeysFromText(trimmed);
  const key = keys[0] || '';
  if (!key && extractApiUrlsFromText(trimmed).length === 0) return null;

  if (lines.length <= 1) {
    const urls = extractApiUrlsFromText(trimmed);
    return { key, url: urls[0] || '' };
  }

  let keyLineIdx = -1;
  for (let i = 0; i < lines.length; i++) {
    if (extractApiKeysFromText(lines[i]).length > 0) {
      keyLineIdx = i;
      break;
    }
  }

  if (keyLineIdx < 0) {
    const urls = extractApiUrlsFromText(trimmed);
    return { key: '', url: urls[0] || '' };
  }

  let url = extractApiUrlsFromText(lines[keyLineIdx])[0] || '';
  if (!url && keyLineIdx > 0) {
    url = extractApiUrlsFromText(lines[keyLineIdx - 1])[0] || '';
  }
  if (!url && keyLineIdx < lines.length - 1) {
    url = extractApiUrlsFromText(lines[keyLineIdx + 1])[0] || '';
  }
  if (!url) {
    url = extractApiUrlsFromText(trimmed)[0] || '';
  }

  return { key, url };
}

function maskApiKey(key) {
  const value = String(key || '').trim();
  if (!value) return '';
  if (value.length <= 12) return value.slice(0, 3) + '***';
  return value.slice(0, 5) + '***' + value.slice(-4);
}

function normalizeBaseUrl(url) {
  return String(url || '').trim().replace(/\/+$/, '');
}

function normalizeBaseUrlForCompare(url) {
  try {
    const u = new URL(url);
    return (u.protocol + '//' + u.host + u.pathname).replace(/\/+$/, '').toLowerCase();
  } catch {
    return url.replace(/\/+$/, '').toLowerCase();
  }
}

function deriveSiteName(baseUrl) {
  try {
    return new URL(baseUrl).hostname.replace(/^(api\.|www\.)/, '');
  } catch {
    return baseUrl;
  }
}

function parseTagsFromText(text) {
  if (!text) return [];
  return text.split(/[,，\n]/).map((s) => s.trim()).filter(Boolean);
}

function sanitizeTags(tags) {
  if (!Array.isArray(tags)) return [];
  return [...new Set(tags.map((t) => String(t).trim()).filter(Boolean))];
}

function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 11);
}

/**
 * 检测站点应归类到 CC-Switch 的哪个 app_type
 * 返回: 'claude' | 'codex' | 'gemini'
 */
function detectCCSAppType(site, models) {
  const name = (site.name || '').toLowerCase();
  const format = (site.detectedFormat || '').toLowerCase();
  const url = (site.baseUrl || '').toLowerCase();

  // 1. 格式为 cch (Claude Code Hub) → Claude
  if (format === 'cch') return 'claude';

  // 2. 名称/URL 关键词匹配
  if (name.includes('claude') || url.includes('claude') || url.includes('anthropic')) return 'claude';
  if (name.includes('gemini') || url.includes('gemini') || url.includes('google')) return 'gemini';
  if (name.includes('codex') || url.includes('codex') || url.includes('openai')) return 'codex';

  // 3. 根据已查询到的模型列表判断
  if (models && models.length > 0) {
    const modelStr = models.map(m => (typeof m === 'string' ? m : m.id || '')).join(' ').toLowerCase();
    if (modelStr.includes('claude')) return 'claude';
    if (modelStr.includes('gemini')) return 'gemini';
  }

  // 4. 默认 → Codex (OpenAI 兼容)
  return 'codex';
}

/**
 * 生成 CC-Switch Deep Link URL
 * 正确协议格式: ccswitch://v1/import?resource=provider&app=xxx&name=xxx&endpoint=xxx&apiKey=xxx
 * 参考: CC-Switch src-tauri/src/deeplink/parser.rs
 */
function buildCCSDeepLink(site, models) {
  const appType = detectCCSAppType(site, models);
  const name = site.name || deriveSiteName(site.baseUrl);
  const baseUrl = normalizeBaseUrl(site.baseUrl);
  const apiKey = site.apiKey || '';

  // 构建 endpoint：Claude 不需要 /v1 后缀，Codex 需要
  let endpoint = baseUrl;
  if (appType === 'claude' || appType === 'gemini') {
    endpoint = baseUrl.replace(/\/v1\/?$/i, '');
  } else {
    endpoint = baseUrl.endsWith('/v1') ? baseUrl : baseUrl + '/v1';
  }

  // ccswitch://v1/import?resource=provider&app=claude&name=xxx&endpoint=xxx&apiKey=xxx
  const params = new URLSearchParams();
  params.set('resource', 'provider');
  params.set('app', appType);
  params.set('name', name);
  params.set('endpoint', endpoint);
  if (apiKey) params.set('apiKey', apiKey);

  return `ccswitch://v1/import?${params.toString()}`;
}

async function copyToClipboard(text) {
  await navigator.clipboard.writeText(text);
}

function formatExpiry(timestamp) {
  if (!timestamp || timestamp <= 0) return null;
  const ts = typeof timestamp === 'number'
    ? (timestamp > 1e12 ? timestamp : timestamp * 1000)
    : new Date(timestamp).getTime();
  const expDate = new Date(ts);
  if (isNaN(expDate.getTime())) return null;

  const remain = ts - Date.now();
  const dateStr = expDate.toLocaleDateString('zh-CN', {
    year: 'numeric', month: '2-digit', day: '2-digit',
  }) + ' ' + expDate.toLocaleTimeString('zh-CN', {
    hour: '2-digit', minute: '2-digit',
  });

  let remainStr, colorClass;
  if (remain <= 0) {
    remainStr = '已过期';
    colorClass = 'text-danger';
  } else {
    const days = Math.floor(remain / 86400000);
    const hrs = Math.floor((remain % 86400000) / 3600000);
    const mins = Math.floor((remain % 3600000) / 60000);
    if (days > 0) remainStr = '剩余 ' + days + '天' + hrs + '小时';
    else if (hrs > 0) remainStr = '剩余 ' + hrs + '小时' + mins + '分';
    else remainStr = '剩余 ' + mins + '分钟';

    if (remain < 86400000) colorClass = 'text-danger';
    else if (remain < 86400000 * 3) colorClass = 'text-warning';
    else colorClass = 'text-muted';
  }

  return `${dateStr} <span class="${colorClass}" style="font-weight:600;">(${remainStr})</span>`;
}
